import { Component, OnInit } from '@angular/core';
import io from 'socket.io-client';
import { Observable } from 'rxjs';

@Component({
  selector: 'app-visualize',
  templateUrl: './visualize.component.html',
  styleUrls: ['./visualize.component.css']
})
export class VisualizeComponent implements OnInit {

  private socket: any;
  constructor() { }

  ngOnInit() {
    this.socket = io("http://localhost:3000");
    return Observable.create((observer) => {
      this.socket.on('stream', (message) => {
          observer.next(message);
      });
  });
  }

}
