import { Component, AfterViewInit } from '@angular/core';
import io from 'socket.io-client';
import { async } from '@angular/core/testing';

@Component({
  selector: 'app-image',
  templateUrl: './image.component.html',
  styleUrls: ['./image.component.css']
})
export class ImageComponent implements AfterViewInit {

  private socket: any;
  private context: any;

  constructor() { 
    this.socket = io("http://localhost:3000");
  }

  ngAfterViewInit(): void {
    const startChat = async () => {
      const localStream = await navigator.mediaDevices.getUserMedia({video: true, audio: true});
      document.querySelector('video#local')['srcObject'] = localStream;

      this.socket.emit('stream', localStream);
    }
    startChat();
  }

}
