import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { VisualizeComponent } from './visualize/visualize.component';
import { ImageComponent } from './image/image.component';

const routes: Routes = [
  {path: 'visual', component: VisualizeComponent},
  {path: 'image', component: ImageComponent},
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
