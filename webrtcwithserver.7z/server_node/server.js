const express = require('express');
const app = express();
const http = require('http').Server(app);
const Socketio = require('socket.io')(http);
const PORT =  process.env.PORT || 3000;

app.use((req,res,next) =>{
    res.header('Access-Control-Allow-Origin',"*");
    next();
})

Socketio.on("connnection",socket => {
    socket.on('stream',(file) =>{
       socket.broadcast.emit('stream',image);
    })
})

http.listen(PORT,() => {
    console.log(`server is working on ${PORT}`);
})


const documents = [{
    id: '1',
    name: 'divay',
},{
    id: '1',
    name: 'divay',
},{
    id: '1',
    name: 'divay',
},{
    id: '1',
    name: 'divay',
},{
    id: '1',
    name: 'divay',
}];
